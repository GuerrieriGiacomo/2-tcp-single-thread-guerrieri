package g1;

import java.io.*;
import java.net.*;

public class Client {
    public static void main(String[] args) {
        try {
            Socket clientSocket = new Socket("localhost", 6789);

            BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter outToServer = new PrintWriter(clientSocket.getOutputStream(), true);
            BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));

            String userInput;
            while ((userInput = inFromUser.readLine()) != null) {
                outToServer.println(userInput);

                if (userInput.equals("BYE")) {
                    break;
                }

                String serverResponse = inFromServer.readLine();
                System.out.println("Server: " + serverResponse);
            }

            clientSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


