package g1;

import java.io.*;
import java.net.*;

public class Server {
    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(6789);
            System.out.println("Server in attesa di connessioni...");
            
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Connessione accettata da: " + clientSocket.getInetAddress());

                BufferedReader inFromClient = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                PrintWriter outToClient = new PrintWriter(clientSocket.getOutputStream(), true);

                String inputLine;
                while ((inputLine = inFromClient.readLine()) != null) {
                    System.out.println("Client: " + inputLine);

                    if (inputLine.equals("BYE")) {
                        break;
                    }

                    String response = inputLine.toUpperCase();
                    outToClient.println(response);
                }

                serverSocket.close();
                clientSocket.close();
                System.out.println("Connessione chiusa.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
    }
}

